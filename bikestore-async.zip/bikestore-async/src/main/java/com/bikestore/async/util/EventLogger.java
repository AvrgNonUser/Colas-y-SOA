package com.bikestore.async.util;

import java.time.Instant;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Registra cada paso del flujo con pedidoId, timestamp y thread,
 * tal como exige el enunciado.
 */
public final class EventLogger {

    private static final Logger LOG = LoggerFactory.getLogger("BikeStore");

    private EventLogger() {
    }

    public static void log(String step, String pedidoId, String detail) {
        LOG.info("[{}] pedidoId={} timestamp={} thread={} | {}",
                step, pedidoId, Instant.now(), Thread.currentThread().getName(), detail);
    }

    public static void warn(String step, String pedidoId, String detail) {
        LOG.warn("[{}] pedidoId={} timestamp={} thread={} | {}",
                step, pedidoId, Instant.now(), Thread.currentThread().getName(), detail);
    }

    public static void error(String step, String pedidoId, String detail) {
        LOG.error("[{}] pedidoId={} timestamp={} thread={} | {}",
                step, pedidoId, Instant.now(), Thread.currentThread().getName(), detail);
    }
}
