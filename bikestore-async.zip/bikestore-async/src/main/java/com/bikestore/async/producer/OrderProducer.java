package com.bikestore.async.producer;

import com.bikestore.async.config.AmqpNames;
import com.bikestore.async.model.OrderItem;
import com.bikestore.async.model.OrderMessage;
import com.bikestore.async.model.OrderRequest;
import com.bikestore.async.util.EventLogger;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.UUID;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Service;

/** Convierte la peticion en un mensaje JSON y lo publica en el broker. */
@Service
public class OrderProducer {

    private final RabbitTemplate rabbitTemplate;

    public OrderProducer(RabbitTemplate rabbitTemplate) {
        this.rabbitTemplate = rabbitTemplate;
    }

    public String publish(OrderRequest request) {
        String pedidoId = "PED-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();

        BigDecimal total = request.items().stream()
                .map(this::lineTotal)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        OrderMessage message = new OrderMessage(
                pedidoId,
                request.customerName(),
                request.customerEmail(),
                request.items(),
                total,
                Instant.now());

        EventLogger.log("OrderProducer", pedidoId,
                "pedido recibido, total=" + total + ", publicando " + AmqpNames.ORDER_CREATED_KEY);

        rabbitTemplate.convertAndSend(
                AmqpNames.ORDERS_EXCHANGE,
                AmqpNames.ORDER_CREATED_KEY,
                message,
                m -> {
                    m.getMessageProperties().setHeader(AmqpNames.HEADER_PEDIDO_ID, pedidoId);
                    return m;
                });

        EventLogger.log("OrderProducer", pedidoId, "mensaje publicado en " + AmqpNames.ORDERS_EXCHANGE);
        return pedidoId;
    }

    private BigDecimal lineTotal(OrderItem item) {
        return item.unitPrice().multiply(BigDecimal.valueOf(item.quantity()));
    }
}
