package com.bikestore.async.model;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import java.math.BigDecimal;

public record OrderItem(
        @NotBlank String sku,
        @Min(1) int quantity,
        @DecimalMin("0.0") BigDecimal unitPrice) {
}
