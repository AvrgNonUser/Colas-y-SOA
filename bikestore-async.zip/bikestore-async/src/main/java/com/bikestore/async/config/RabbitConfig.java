package com.bikestore.async.config;

import com.bikestore.async.util.EventLogger;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.core.QueueBuilder;
import org.springframework.amqp.AmqpRejectAndDontRequeueException;
import org.springframework.amqp.rabbit.retry.MessageRecoverer;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.amqp.support.converter.MessageConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitConfig {

    // ---------- Exchanges ----------
    @Bean
    DirectExchange ordersExchange() {
        return new DirectExchange(AmqpNames.ORDERS_EXCHANGE);
    }

    @Bean
    DirectExchange deadLetterExchange() {
        return new DirectExchange(AmqpNames.DEAD_LETTER_EXCHANGE);
    }

    // ---------- Colas ----------
    /** Cola de pagos: si el mensaje se rechaza sin reencolar, va al DLX. */
    @Bean
    Queue paymentQueue() {
        return QueueBuilder.durable(AmqpNames.PAYMENT_QUEUE)
                .deadLetterExchange(AmqpNames.DEAD_LETTER_EXCHANGE)
                .deadLetterRoutingKey(AmqpNames.PAYMENT_DEAD_KEY)
                .build();
    }

    @Bean
    Queue emailQueue() {
        return QueueBuilder.durable(AmqpNames.EMAIL_QUEUE).build();
    }

    /** Dead-Letter Queue para analisis offline. */
    @Bean
    Queue paymentDeadLetterQueue() {
        return QueueBuilder.durable(AmqpNames.PAYMENT_DLQ).build();
    }

    // ---------- Bindings ----------
    @Bean
    Binding paymentBinding(Queue paymentQueue, DirectExchange ordersExchange) {
        return BindingBuilder.bind(paymentQueue).to(ordersExchange).with(AmqpNames.ORDER_CREATED_KEY);
    }

    @Bean
    Binding emailBinding(Queue emailQueue, DirectExchange ordersExchange) {
        return BindingBuilder.bind(emailQueue).to(ordersExchange).with(AmqpNames.ORDER_PAID_KEY);
    }

    @Bean
    Binding deadLetterBinding(Queue paymentDeadLetterQueue, DirectExchange deadLetterExchange) {
        return BindingBuilder.bind(paymentDeadLetterQueue).to(deadLetterExchange)
                .with(AmqpNames.PAYMENT_DEAD_KEY);
    }

    // ---------- JSON ----------
    @Bean
    MessageConverter jsonMessageConverter(ObjectMapper objectMapper) {
        return new Jackson2JsonMessageConverter(objectMapper);
    }

    // ---------- Reintentos agotados -> DLQ ----------
    /**
     * Spring Boot lo usa automaticamente cuando se agotan los reintentos del listener.
     * Rechaza el mensaje sin reencolar, por lo que RabbitMQ lo reenvia al DLX/DLQ.
     */
    @Bean
    MessageRecoverer deadLetterRecoverer() {
        return (message, cause) -> {
            Object pedidoId = message.getMessageProperties().getHeader(AmqpNames.HEADER_PEDIDO_ID);
            EventLogger.error("DLQ", String.valueOf(pedidoId),
                    "reintentos agotados, enviando a " + AmqpNames.PAYMENT_DLQ
                            + " | causa: " + rootMessage(cause));
            throw new AmqpRejectAndDontRequeueException("Reintentos agotados", cause);
        };
    }

    private static String rootMessage(Throwable t) {
        Throwable root = t;
        while (root.getCause() != null) {
            root = root.getCause();
        }
        return root.getMessage();
    }
}
