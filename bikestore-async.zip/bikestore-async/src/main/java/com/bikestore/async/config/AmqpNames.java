package com.bikestore.async.config;

public final class AmqpNames {

    public static final String ORDERS_EXCHANGE = "bikestore.orders";
    public static final String PAYMENT_QUEUE = "bikestore.payment.queue";
    public static final String EMAIL_QUEUE = "bikestore.email.queue";

    public static final String ORDER_CREATED_KEY = "order.created";
    public static final String ORDER_PAID_KEY = "order.paid";

    public static final String DEAD_LETTER_EXCHANGE = "bikestore.dlx";
    public static final String PAYMENT_DLQ = "bikestore.payment.dlq";
    public static final String PAYMENT_DEAD_KEY = "payment.dead";

    public static final String HEADER_PEDIDO_ID = "pedidoId";

    private AmqpNames() {
    }
}
