package com.bikestore.async.producer;

import com.bikestore.async.model.OrderRequest;
import jakarta.validation.Valid;
import java.util.Map;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** API "Ordenar" que invoca el front-end al confirmar un pedido. */
@RestController
@RequestMapping("/api")
public class OrderProducerController {

    private final OrderProducer orderProducer;

    public OrderProducerController(OrderProducer orderProducer) {
        this.orderProducer = orderProducer;
    }

    @PostMapping("/ordenar")
    public ResponseEntity<Map<String, String>> ordenar(@Valid @RequestBody OrderRequest request) {
        String pedidoId = orderProducer.publish(request);
        // 202: el pedido fue aceptado, se procesara de forma asincrona
        return ResponseEntity.accepted().body(Map.of(
                "pedidoId", pedidoId,
                "estado", "ACEPTADO_PARA_PROCESAMIENTO"));
    }
}
