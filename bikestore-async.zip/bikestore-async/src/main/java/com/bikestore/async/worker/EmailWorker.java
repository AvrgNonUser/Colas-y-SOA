package com.bikestore.async.worker;

import com.bikestore.async.config.AmqpNames;
import com.bikestore.async.model.PaymentProcessedEvent;
import com.bikestore.async.model.PaymentStatus;
import com.bikestore.async.util.EventLogger;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.stereotype.Component;

/** Envia (simulado) el e-mail de confirmacion solo si paymentStatus=PAID. */
@Component
public class EmailWorker {

    @RabbitListener(queues = AmqpNames.EMAIL_QUEUE)
    public void handle(PaymentProcessedEvent event) {
        EventLogger.log("EmailWorker", event.pedidoId(),
                "evento recibido, paymentStatus=" + event.paymentStatus());

        if (event.paymentStatus() != PaymentStatus.PAID) {
            EventLogger.warn("EmailWorker", event.pedidoId(),
                    "pago no confirmado, NO se envia e-mail");
            return;
        }

        EventLogger.log("EmailWorker", event.pedidoId(),
                "e-mail enviado a " + event.customerEmail()
                        + " | Hola " + event.customerName()
                        + ", tu pedido " + event.pedidoId()
                        + " por $" + event.total() + " fue confirmado");
    }
}
