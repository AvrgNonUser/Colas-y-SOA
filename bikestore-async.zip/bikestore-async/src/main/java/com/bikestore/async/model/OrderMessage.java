package com.bikestore.async.model;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;

/** Mensaje JSON publicado por OrderProducer (routing key order.created). */
public record OrderMessage(
        String pedidoId,
        String customerName,
        String customerEmail,
        List<OrderItem> items,
        BigDecimal total,
        Instant createdAt) {
}
