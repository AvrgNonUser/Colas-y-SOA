package com.bikestore.async.model;

public enum PaymentStatus {
    PAID,
    FAILED
}
