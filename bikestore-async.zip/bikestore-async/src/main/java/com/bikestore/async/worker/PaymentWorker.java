package com.bikestore.async.worker;

import com.bikestore.async.config.AmqpNames;
import com.bikestore.async.model.OrderMessage;
import com.bikestore.async.model.PaymentProcessedEvent;
import com.bikestore.async.model.PaymentStatus;
import com.bikestore.async.util.EventLogger;
import java.time.Instant;
import java.util.concurrent.ThreadLocalRandom;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.retry.RetryContext;
import org.springframework.retry.support.RetrySynchronizationManager;
import org.springframework.stereotype.Component;

/**
 * Simula el cobro con tarjeta. Falla con probabilidad configurable (50 % por defecto).
 * Los reintentos y el envio a DLQ los gestiona Spring Retry + RabbitConfig.
 */
@Component
public class PaymentWorker {

    private final RabbitTemplate rabbitTemplate;
    private final double failureRate;

    public PaymentWorker(RabbitTemplate rabbitTemplate,
                         @Value("${bikestore.payment.failure-rate:0.5}") double failureRate) {
        this.rabbitTemplate = rabbitTemplate;
        this.failureRate = failureRate;
    }

    @RabbitListener(queues = AmqpNames.PAYMENT_QUEUE)
    public void handle(OrderMessage order) {
        int attempt = currentAttempt();
        EventLogger.log("PaymentWorker", order.pedidoId(),
                "procesando cobro de " + order.total() + " (intento " + attempt + ")");

        if (ThreadLocalRandom.current().nextDouble() < failureRate) {
            EventLogger.warn("PaymentWorker", order.pedidoId(),
                    "cobro RECHAZADO en intento " + attempt);
            throw new PaymentDeclinedException("Tarjeta rechazada (simulado) para " + order.pedidoId());
        }

        EventLogger.log("PaymentWorker", order.pedidoId(), "cobro EXITOSO, paymentStatus=PAID");

        PaymentProcessedEvent event = new PaymentProcessedEvent(
                order.pedidoId(),
                order.customerName(),
                order.customerEmail(),
                order.total(),
                PaymentStatus.PAID,
                Instant.now());

        rabbitTemplate.convertAndSend(
                AmqpNames.ORDERS_EXCHANGE,
                AmqpNames.ORDER_PAID_KEY,
                event,
                m -> {
                    m.getMessageProperties().setHeader(AmqpNames.HEADER_PEDIDO_ID, order.pedidoId());
                    return m;
                });

        EventLogger.log("PaymentWorker", order.pedidoId(), "evento " + AmqpNames.ORDER_PAID_KEY + " publicado");
    }

    private int currentAttempt() {
        RetryContext ctx = RetrySynchronizationManager.getContext();
        return ctx == null ? 1 : ctx.getRetryCount() + 1;
    }
}
