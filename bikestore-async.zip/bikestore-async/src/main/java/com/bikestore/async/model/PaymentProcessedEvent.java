package com.bikestore.async.model;

import java.math.BigDecimal;
import java.time.Instant;

/** Evento publicado por PaymentWorker (routing key order.paid). */
public record PaymentProcessedEvent(
        String pedidoId,
        String customerName,
        String customerEmail,
        BigDecimal total,
        PaymentStatus paymentStatus,
        Instant processedAt) {
}
